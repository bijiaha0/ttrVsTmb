%GDC
clear 
close all
%% ��ȡ����
mu=load('luadGDCmu.mat'); %HugoSymbol EntrezGene chrom startpo endpo VariantClass VariantType Ref Tum1 Tum2 pidt
%load luadGDCclinical.mat  PatientID &�ٴ�����

%% �Զ��嶨��TMB��TTRͻ��
%issilent=find(ismember(mu.VariantClass,{'Silent'})==0);%��Ӧ���ݵ�9�з�silentͻ��λ��
issnp=find(cellfun(@str2double,mu.VariantType)~=0);%��Ӧ���ݵ�10������Typeͻ�䣨INS DEL SNV)

tum1aut=mu.Tum1(issnp);
tum2aut=mu.Tum2(issnp);
chromaut=mu.chrom(issnp);
startpoaut=mu.startpo(issnp);
pidtaut=mu.pidt(issnp);
geneidaut=mu.HugoSymbol(issnp);
caseid=unique(pidtaut,'stable');
Patient=caseid;
base={'C';'G';'T';'A'};

for l=1:length(caseid)
    isit=ismember(pidtaut,caseid{l});
    %% ÿ�����˵�TMB:tumor mutation burden
    TMB(l)=length(find(isit~=0));
    
    tum1now=tum1aut(isit);
    tum2now=tum2aut(isit);
    count=zeros(4,4);
    for j=1:4
        isA=ismember(tum1now,base{j});
        tum2temp=tum2now(isA);
        tt=1:4;
        tt(j)=[];
        for i=tt
            if ~isempty(tum2temp)
                isit=ismember(tum2temp,base{i});
                count(j,i)=length(find(isit~=0));
                clear isit
            else
                count(j,i)=0;
            end
        end
        clear tum2temp
    end
    % ��ÿ�����˵ĺ�����ͻ����
    transition(l)=count(1,3)+count(2,4);%+count(3,1)+count(4,2);
    transversion(l)=count(1,4)+count(2,3);%+count(1,2)+count(2,1)+count(3,2)+count(3,4)+count(4,3)+count(4,1);
    ct(l)=count(1,3);
    tc(l)=count(3,1);
    ga(l)=count(2,4);
    ag(l)=count(4,2);
    gt(l)=count(2,3);
    tg(l)=count(3,2);
    ca(l)=count(1,4);
    ac(l)=count(4,1);
    gc(l)=count(2,1);
    cg(l)=count(1,2);
    ta(l)=count(3,4);
    at(l)=count(4,3);
    
    %% TTratio
    if transition(l)~=0
        TTratio(l)=transversion(l)/transition(l);
    else
        TTratio(l)=0;
    end
    
end

save dataprocess.mat TMB TTratio Patient

