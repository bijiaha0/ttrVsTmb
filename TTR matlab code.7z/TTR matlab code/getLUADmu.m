clear all
fileID = fopen('gdcmutect.txt','r');
slCharacterEncoding('ISO-8859-1')
%nNumberCols =113;
nNumberCols =114;%������114��
format = ['%s ' repmat('%s ', [1 nNumberCols])];
A=textscan(fileID,format,10000,'Headerlines', 2,'Delimiter','\t');%������10000�У����б���ռ����
%keyboard
HugoSymbol=A{1,1};
EntrezGene=A{1,2};
chrom=A{1,5};
startpo=A{1,6};
endpo=A{1,7};
VariantClass=A{1,9};
VariantType=A{1,10};
Ref=A{1,11};
Tum1=A{1,12};
Tum2=A{1,13};
pidtemp=char(A{1,16});
pidt=cellstr(pidtemp(:,1:12));
fclose(fileID);

save luadGDCmu.mat HugoSymbol EntrezGene chrom startpo endpo VariantClass VariantType Ref Tum1 Tum2 pidt
